# Luméra Care - تطبيق العميل (Android)

تطبيق العميل فقط (متجر + مقدمة الفيديو + ودجت الدعم). لا يحتوي أي كود إدارة. يتصل بنفس Firebase الذي تتصل به لوحة الإدارة.

## قبل البناء
1. جهّز Firebase مرة واحدة حسب الملف `FIREBASE-SETUP.md` (الدخول بالهاتف + Firestore + القواعد `firebase/firestore.rules`).
2. افتح `public/config.js` وضع قيم مشروعك (apiKey وغيرها).
3. ثبّت المتطلبات: Node 18 أو أحدث، JDK 17 (أو 21)، Android Studio مع Android SDK (يُكتشف مسار الـ SDK تلقائياً أو عرّف ANDROID_HOME). للتحقق من جاهزية جهازك قبل البناء: `npm run doctor`.

## بناء الـ APK
```
npm install
npm run apk:debug
```
الناتج (الأمر المختصر: `npm run apk`): `lumera-care-v1.1-debug.apk` في مجلد المشروع. الأمر يبني الواجهة وينشئ مشروع android ويولّد الأيقونات (في أول مرة) ثم يشغّل Gradle. أول مرة قد تستغرق عدة دقائق لتنزيل Gradle.
للنسخة النهائية: `npm run apk:release` (ينتج APK غير موقّع، وقّعه بمفتاحك من Android Studio: Build > Generate Signed Bundle / APK).

## تغيير الإعدادات لاحقاً
أي تعديل على `public/config.js` أو الكود يتطلب إعادة `npm run apk:debug`.

## التطوير على الويب
`npm run dev` ثم افتح العنوان المعروض.

## ملفات المقدمة
`public/splash.mp4` و `public/splash.webm` و `public/splash-poster.jpg`: تبقى 5 ثوانٍ كاملة على الأقل، وفيها زر "تخطي" من الثانية 0.

## إعادة إنشاء مشروع android
إذا غيّرت نسخة JDK أو `capacitor.config.json` وظهر خطأ في Gradle: `npm run apk:reset` ثم `npm run apk:debug`.

## رفع رقم الإصدار
عدّل الكتلة `android` في `package.json` (`versionName` و `versionCode`). يجب أن يزيد `versionCode` في كل تحديث جديد، ويُطبَّق تلقائياً عند كل بناء.

## اسم التطبيق وأيقونته
- الاسم الظاهر على الهاتف: `appName` في `capacitor.config.json` (حالياً: Luméra). يُطبَّق تلقائياً على `strings.xml` و`AndroidManifest.xml` عند كل بناء.
- الأيقونة: ملفات `resources/icon-only.png` و`icon-foreground.png` و`icon-background.png` (1024×1024). تُولَّد منها أيقونات أندرويد كلها عند كل بناء. الشعار الكامل الأصلي محفوظ في `resources/logo-full.png`.
