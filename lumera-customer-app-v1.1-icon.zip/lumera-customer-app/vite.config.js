import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// base "./" يجعل المسارات نسبية ليعمل التطبيق داخل Capacitor (WebView) بدون خادم
export default defineConfig({ base: "./", plugins: [react()], build: { outDir: "dist", target: "es2019", chunkSizeWarningLimit: 900 } });
