import React from "react";
import { createRoot } from "react-dom/client";
import { Capacitor } from "@capacitor/core";
import { App as CapApp } from "@capacitor/app";
// خط Cairo مضمّن داخل التطبيق ليعمل بدون إنترنت
import "@fontsource/cairo/arabic-400.css";
import "@fontsource/cairo/arabic-600.css";
import "@fontsource/cairo/arabic-700.css";
import "@fontsource/cairo/arabic-800.css";
import "@fontsource/cairo/latin-400.css";
import "@fontsource/cairo/latin-600.css";
import "@fontsource/cairo/latin-700.css";
import "@fontsource/cairo/latin-800.css";
import "./index.css";
import App from "./App.jsx";

createRoot(document.getElementById("root")).render(<App />);

// زر الرجوع في أندرويد: يغلق أولاً أي شاشة/نافذة مفتوحة (المحادثة، السلة...) وإلا يغلق التطبيق
if (Capacitor.isNativePlatform()) {
  CapApp.addListener("backButton", () => {
    const ev = new CustomEvent("lumera:back", { cancelable: true });
    if (window.dispatchEvent(ev)) CapApp.exitApp(); // false = تم التعامل معه (preventDefault)
  });
}
