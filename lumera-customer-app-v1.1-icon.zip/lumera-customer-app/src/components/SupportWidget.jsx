import React, { useState, useEffect, useCallback } from "react";
import { ChatI } from "./ui";
import { ChatScreen } from "./ChatScreen";
import { SUPPORT_NAME } from "../lib/theme";

/* ودجت الدعم: زر عائم فوق شريط التنقل يفتح محادثة بملء الشاشة (ChatScreen) باسم Luméra Team support.
   يعمل للعميل المسجل وللزائر (معرّف مؤقت محفوظ على الجهاز). */
export const AUTO_REPLY = "أهلاً بك في Luméra Care. وصلتنا رسالتك وسيرد عليك فريقنا خلال لحظات."; // يجب أن يطابق firestore.rules
export function SupportWidget({ db, update, user, uid, ensureAuth }) {
  const [open, setOpen] = useState(false); const [seen, setSeen] = useState(0); const [msg, setMsg] = useState(""); const [err, setErr] = useState("");
  const cm = (uid && db.chats[uid]) || [], last = cm[cm.length - 1];
  const unread = !open && !!last && last.from === "s" && cm.length > seen;
  const online = Object.values(db.presence || {}).some(Boolean);
  useEffect(() => { if (open) setSeen(cm.length); }, [open, cm.length]); // الرسائل المعروضة تُعتبر مقروءة
  const close = useCallback(() => { setOpen(false); setErr(""); }, []);
  const send = async (e) => {
    e.preventDefault(); const t = msg.trim(); if (!t) return; setMsg(""); setErr("");
    try {
      const id = uid || (await ensureAuth()); // الزائر يحصل على حساب مجهول عند أول رسالة فقط
      await update((d) => {
        const a = (d.chats[id] = d.chats[id] || []);
        a.push({ from: "c", t, at: Date.now(), name: user ? user.name : "زائر" });
        if (!a.some((m) => m.from === "s")) a.push({ from: "s", auto: true, t: AUTO_REPLY, at: Date.now() + 1 });
        return d;
      });
    } catch { setMsg(t); setErr("تعذر إرسال الرسالة، تحقق من الاتصال وحاول مجدداً"); } // لا نفقد نص العميل عند الفشل
  };
  return (
    <>
      {open && <ChatScreen messages={cm} online={online} msg={msg} setMsg={setMsg} onSend={send} onClose={close} error={err} />}
      {!open && (
        <button onClick={() => setOpen(true)} aria-label={SUPPORT_NAME} aria-haspopup="dialog" className="fixed bottom-[calc(5.25rem+env(safe-area-inset-bottom,0px))] end-4 z-[45] flex h-14 w-14 items-center justify-center rounded-full bg-[#5F6E30] text-[#FAF7EE] shadow-[0_8px_24px_rgba(75,85,40,0.35)] transition hover:bg-[#505D28] active:scale-95">
          <span className="scale-125">{ChatI}</span>{unread && <span className="absolute -end-1 -top-1 h-3.5 w-3.5 rounded-full bg-[#C9A227] ring-2 ring-[#FAF7EE]" />}
        </button>
      )}
    </>
  );
}
