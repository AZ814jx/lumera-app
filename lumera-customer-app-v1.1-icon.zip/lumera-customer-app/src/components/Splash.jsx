import React, { useState, useEffect } from "react";

/* ---------- شاشة البداية: مقدمة ترويجية للعملاء والزوار فقط ----------
   تبقى ظاهرة 5 ثوانٍ كاملة على الأقل (أو طول الفيديو إن كان أطول) ولا تُغلق بسبب أي خطأ في الفيديو:
   إن تعذر التشغيل تظهر الصورة الترويجية الثابتة طوال المدة. تُغلق فقط عند انتهاء المدة أو بزر "تخطي".
   الملفات: /splash.mp4 و /splash.webm و /splash-poster.jpg (أو عرّف window.SPLASH_SRC / SPLASH_WEBM / SPLASH_POSTER). */
const SW = typeof window !== "undefined" ? window : {};
const BASE = (typeof import.meta !== "undefined" && import.meta.env && import.meta.env.BASE_URL) || "/";
const SPLASH_SRC = SW.SPLASH_SRC || BASE + "splash.mp4", SPLASH_WEBM = SW.SPLASH_WEBM || BASE + "splash.webm", SPLASH_POSTER = SW.SPLASH_POSTER || BASE + "splash-poster.jpg";
// خلفية داكنة مأخوذة من ألوان حواف الفيديو (أعلى/وسط/أسفل) كي تندمج الأشرطة الجانبية مع التصميم
const SPLASH_MS = 5000, SPLASH_BG = "linear-gradient(180deg, #522F36 0%, #3F242B 50%, #25161B 100%)";
// object-contain: يظهر التصميم الإعلاني كاملاً بلا أي قص على كل أحجام الشاشات
const SPLASH_FIT = "absolute inset-0 h-full w-full bg-transparent object-contain object-center";

export function Splash({ onDone }) {
  const [start] = useState(() => Date.now());
  const [ms, setMs] = useState(SPLASH_MS); const [out, setOut] = useState(false);
  const [playing, setPlaying] = useState(false); const [failed, setFailed] = useState(false); const [late, setLate] = useState(false);
  const finish = () => { setOut(true); setTimeout(onDone, 500); }; // تلاشٍ ناعم ثم إزالة الشاشة
  useEffect(() => { const t = setTimeout(finish, Math.max(0, start + ms - Date.now())); return () => clearTimeout(t); }, [ms]); // مدة مضمونة
  useEffect(() => { const t = setTimeout(() => setLate(true), 1200); return () => clearTimeout(t); }, []); // الصورة تظهر إن تأخر الفيديو
  const meta = (e) => {
    const v = e.currentTarget; v.muted = true;
    const pr = v.play(); if (pr && pr.catch) pr.catch(() => {}); // حظر التشغيل التلقائي لا يغلق الشاشة
    if (v.duration && isFinite(v.duration)) setMs(Math.max(SPLASH_MS, Math.round(v.duration * 1000) + 250)); // لا نقطع فيديو أطول من 5 ثوانٍ
  };
  return (
    <div role="presentation" style={{ background: SPLASH_BG }} className={`fixed inset-0 z-[100] overflow-hidden transition-opacity duration-500 motion-reduce:transition-none ${out ? "pointer-events-none opacity-0" : "opacity-100"}`}>
      <p className="sr-only">مقدمة Luméra Care</p>
      {!playing && (failed || late) && <img src={SPLASH_POSTER} alt="" aria-hidden="true" className={SPLASH_FIT} />}
      <video aria-hidden="true" autoPlay muted playsInline preload="auto" disablePictureInPicture className={SPLASH_FIT + (failed ? " hidden" : "")}
        onLoadedMetadata={meta} onPlaying={() => setPlaying(true)} onEnded={() => { if (Date.now() - start >= SPLASH_MS) finish(); }}>
        <source src={SPLASH_SRC} type="video/mp4" />
        <source src={SPLASH_WEBM} type="video/webm" onError={() => setFailed(true)} />
      </video>
      <button type="button" onClick={finish} aria-label="تخطي المقدمة" style={{ top: "calc(env(safe-area-inset-top, 0px) + 1rem)" }}
        className="absolute end-4 z-10 flex min-h-11 min-w-[4.5rem] items-center justify-center rounded-full border border-[#FDFBF7]/40 bg-[#FDFBF7]/20 px-4 text-sm font-bold text-[#FDFBF7] backdrop-blur-sm transition hover:bg-[#FDFBF7]/35 active:scale-95">تخطي</button>
    </div>
  );
}
