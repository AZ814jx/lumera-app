import React, { useEffect, useRef } from "react";
import { Svg } from "./ui";
import { OL, SUPPORT_NAME } from "../lib/theme";

/* واجهة محادثة الدعم بملء الشاشة (RTL):
   رأس داكن ثابت + منطقة رسائل قابلة للتمرير + شريط إدخال ثابت بالأسفل.
   تحترم المناطق الآمنة (notch / شريط الإيماءات) وتتكيف مع لوحة المفاتيح. */
const BackI = <Svg c="h-6 w-6" d={<path d="M9 5l7 7-7 7" />} />;
const SendI = <Svg c="h-5 w-5 -scale-x-100" d={<path d="M4 12l16-8-6 16-3-7z" />} />; // مقلوب ليناسب الاتجاه RTL
const hhmm = (t) => new Date(t).toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit" });

export function ChatScreen({ messages, online, msg, setMsg, onSend, onClose, error }) {
  const end = useRef(null);
  const toBottom = () => { if (end.current) end.current.scrollIntoView({ block: "end" }); };
  useEffect(toBottom, [messages.length]);
  useEffect(() => { window.addEventListener("resize", toBottom); return () => window.removeEventListener("resize", toBottom); }, []); // عند ظهور/إخفاء لوحة المفاتيح
  useEffect(() => { const h = (e) => { e.preventDefault(); onClose(); }; window.addEventListener("lumera:back", h); return () => window.removeEventListener("lumera:back", h); }, [onClose]); // زر الرجوع في أندرويد

  return (
    <div role="dialog" aria-modal="true" aria-label={SUPPORT_NAME} dir="rtl" className={`full-vh fixed inset-0 z-[70] flex flex-col overflow-hidden ${OL.page}`}>
      <header style={{ paddingTop: "env(safe-area-inset-top, 0px)" }} className="shrink-0 bg-[#2F3A17] text-[#FAF7EE] shadow-md">
        <div className="flex h-16 items-center gap-3 px-3">
          <button type="button" onClick={onClose} aria-label="رجوع" className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full transition hover:bg-[#FAF7EE]/15 active:scale-95">{BackI}</button>
          <div aria-hidden="true" className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-[#5F6E30] text-lg font-extrabold">L</div>
          <div className="min-w-0 flex-1">
            <b dir="ltr" className="block truncate text-start text-base leading-tight">{SUPPORT_NAME}</b>
            <p className="mt-0.5 flex items-center gap-1.5 text-xs opacity-90"><span aria-hidden="true" className={`h-2 w-2 rounded-full ${online ? "bg-[#9BD06B]" : "bg-[#C9A227]"}`} />{online ? "متاح الآن" : "نرد عليك في أقرب وقت"}</p>
          </div>
        </div>
      </header>

      <main aria-live="polite" className="min-h-0 flex-1 overflow-y-auto overscroll-contain bg-[#FAF7EE]">
        <div className="flex min-h-full flex-col justify-end gap-2 px-3 py-4">
          {!messages.length && <p className={`mx-auto max-w-xs rounded-2xl px-4 py-2 text-center text-sm ${OL.badge}`}>مرحباً بك. اكتب سؤالك وسيساعدك فريق الدعم فوراً.</p>}
          {messages.map((m, i) => {
            const mine = m.from === "c"; // رسائل العميل يميناً، ردود الدعم يساراً
            return (
              <div key={i} className={`flex max-w-[82%] flex-col ${mine ? "items-start self-start" : "items-end self-end"}`}>
                <div className={`whitespace-pre-wrap break-words rounded-2xl px-3.5 py-2 text-sm leading-relaxed ${mine ? "rounded-es-md " + OL.bubbleMe : "rounded-ee-md " + OL.bubbleTeam}`}>
                  {!mine && <span dir="ltr" className="mb-0.5 block text-start text-[10px] font-bold opacity-80">{SUPPORT_NAME}</span>}
                  <span dir="auto">{m.t}</span>
                </div>
                <span className={`mt-0.5 px-1 text-[10px] ${OL.muted}`}>{hhmm(m.at)}</span>
              </div>
            );
          })}
          <div ref={end} />
        </div>
      </main>

      <form onSubmit={onSend} style={{ paddingBottom: "max(0.75rem, env(safe-area-inset-bottom, 0px))" }} className="shrink-0 border-t border-[#D5DBB8] bg-[#F3EFE0] px-3 pt-3">
        {error && <p role="alert" className="mb-2 rounded-xl bg-[#F4E6DE] px-3 py-1.5 text-xs font-semibold text-[#744838]">{error}</p>}
        <div className="flex items-center gap-2">
          <input value={msg} onChange={(e) => setMsg(e.target.value)} dir="auto" enterKeyHint="send" autoComplete="off" maxLength={1000} placeholder="اكتب رسالتك..." aria-label="رسالتك" className={OL.input + " !h-12 flex-1 !rounded-full !px-4 !text-base"} />
          <button type="submit" disabled={!msg.trim()} aria-label="إرسال" className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-[#5F6E30] text-[#FAF7EE] transition hover:bg-[#505D28] active:scale-95 disabled:opacity-50">{SendI}</button>
        </div>
      </form>
    </div>
  );
}
