import React, { useState, useEffect } from "react";
import { D, ST } from "../lib/format";

export const cardC = "rounded-3xl bg-[#F4EFE6] shadow-[0_6px_22px_rgba(120,90,70,0.08)]";
export const btnP = "h-11 rounded-xl bg-[#C89F8B] px-5 text-sm font-bold text-stone-800 shadow-sm shadow-[#C89F8B]/30 transition hover:bg-[#B98A75] active:scale-95 disabled:opacity-60";
export const btnG = "h-10 rounded-xl border border-[#E3D5C6] bg-[#F4EFE6] px-4 text-sm font-semibold text-stone-600 transition hover:border-[#D9B5A3] hover:text-[#8A5A47] active:scale-95";
export const inC = "h-11 w-full rounded-xl border border-[#E3D5C6] bg-[#FDFBF7] px-3 text-sm text-stone-800 outline-none transition placeholder:text-stone-500 focus:border-[#C89F8B] focus:bg-[#F4EFE6] focus:ring-4 focus:ring-[#EBCFC3]";

export const Svg = ({ d, c = "h-5 w-5" }) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" className={c} aria-hidden="true">{d}</svg>
);
export const PhoneI = <Svg d={<path d="M5 4h3.5l1.5 4-2 1.5a11 11 0 005 5l1.5-2L18.5 14v3.5a2 2 0 01-2 2A14 14 0 013 6a2 2 0 012-2z" />} />;
export const LockI = <Svg d={<><rect x="4" y="11" width="16" height="10" rx="3" /><path d="M8 11V8a4 4 0 118 0v3" /></>} />;
export const CartI = <Svg d={<><path d="M5 7h14l-1.5 12h-11z" /><path d="M9 7a3 3 0 016 0" /></>} />;

export const Field = ({ label, error, children }) => (
  <label className="block">
    <span className="mb-1 block text-sm font-semibold text-stone-700">{label}</span>
    {children}
    {error && <span role="alert" className="mt-1 block text-xs font-medium text-[#8A5A47]">{error}</span>}
  </label>
);
export const PhoneField = ({ value, onChange, error, label = "رقم الهاتف" }) => (
  <Field label={label} error={error}>
    <div className="flex h-11 items-center gap-2 rounded-xl border border-[#E3D5C6] bg-[#FDFBF7] px-3 transition focus-within:border-[#C89F8B] focus-within:bg-[#F4EFE6] focus-within:ring-4 focus-within:ring-[#EBCFC3]">
      <span className="text-stone-500">{PhoneI}</span>
      <div dir="ltr" className="flex flex-1 items-center gap-2">
        <b className="text-sm text-stone-700">+964</b><i className="h-4 w-px bg-[#E3D5C6]" />
        <input inputMode="numeric" value={value} placeholder="7XX XXX XXXX" className="w-full bg-transparent text-sm outline-none placeholder:text-stone-500"
          onChange={(e) => onChange(e.target.value.replace(/[٠-٩]/g, (c) => c.charCodeAt(0) - 1632).replace(/\D/g, "").replace(/^964/, "").replace(/^0+/, "").slice(0, 10))} />
      </div>
    </div>
  </Field>
);
export const Badge = ({ children, tone = "slate" }) => (
  <span className={`inline-block rounded-full px-2.5 py-0.5 text-xs font-bold ${{ slate: "bg-[#EEDFD2] text-stone-600", rose: "bg-[#EBCFC3] text-[#744838]", green: "bg-[#DDE8D5] text-[#4A6340]", amber: "bg-[#F3E3C3] text-[#7A5A1E]" }[tone]}`}>{children}</span>
);
export const stTone = (s) => ({ [ST[0]]: "amber", [ST[1]]: "rose", [ST[2]]: "green", [ST[3]]: "slate" }[s]);
export const Brand = ({ sub }) => (
  <div className="flex items-baseline gap-3">
    <span dir="ltr" className="text-xl font-extrabold tracking-wide text-stone-800">Luméra <span className="font-semibold text-[#B98A75]">Care</span></span>
    {sub && <span className="rounded-full bg-[#F4E6DE] px-2.5 py-0.5 text-xs font-bold text-[#8A5A47]">{sub}</span>}
  </div>
);
export const Modal = ({ title, onClose, children }) => {
  useEffect(() => { const h = (e) => { e.preventDefault(); onClose(); }; window.addEventListener("lumera:back", h); return () => window.removeEventListener("lumera:back", h); }, [onClose]); // زر الرجوع في أندرويد يغلق النافذة
  return (
  <div className="fixed inset-0 z-50 flex items-end justify-center bg-[#4A3B34]/40 p-0 sm:items-center sm:p-4" onClick={onClose}>
    <div role="dialog" aria-modal="true" aria-label={title} onClick={(e) => e.stopPropagation()} className="max-h-[92vh] w-full max-w-lg overflow-y-auto rounded-t-3xl bg-[#F4EFE6] p-5 shadow-2xl sm:rounded-3xl">
      <div className="mb-4 flex items-center justify-between"><h2 className="text-lg font-extrabold text-stone-800">{title}</h2><button onClick={onClose} className={btnG}>إغلاق</button></div>
      {children}
    </div>
  </div>
  );
};
export const Bottle = ({ img, name }) => img ? <img src={img} alt={name} className="h-32 w-full rounded-xl object-cover" /> : (
  <div className="flex h-32 items-center justify-center rounded-xl bg-gradient-to-br from-[#F4E6DE] to-[#EEDFD2]">
    <svg width="44" height="70" viewBox="0 0 44 60" aria-hidden="true"><rect x="14" y="0" width="16" height="12" rx="3" fill="#B98A75" /><rect x="4" y="12" width="36" height="48" rx="11" fill="#D9B5A3" /></svg>
  </div>
);

export const Collapse = ({ open, children }) => (
  <div aria-hidden={!open} {...(open ? {} : { inert: "" })} className={`grid transition-all duration-300 ease-out motion-reduce:transition-none ${open ? "grid-rows-[1fr] opacity-100" : "invisible grid-rows-[0fr] opacity-0"}`}>
    <div className="overflow-hidden"><div className="space-y-4 pb-0.5">{children}</div></div>
  </div>
);

export function PasswordField({ id, label, value, onChange, error, auto }) {
  const [show, setShow] = useState(false);
  return (
    <Field label={label} error={error}>
      <div className="relative">
        <input id={id} type={show ? "text" : "password"} autoComplete={auto} value={value} onChange={onChange} placeholder="••••••••" className={inC + " pe-16"} />
        <button type="button" onClick={() => setShow(!show)} aria-label={show ? "إخفاء كلمة المرور" : "إظهار كلمة المرور"} className="absolute end-3 top-3 text-xs font-bold text-[#8A5A47]">{show ? "إخفاء" : "إظهار"}</button>
      </div>
    </Field>
  );
}

export function PromoBanner({ img, title, sub }) {
  if (img) return (
    <div className="mb-5 overflow-hidden rounded-3xl shadow-[0_6px_22px_rgba(120,90,70,0.10)]">
      <img src={img} alt={title || "عرض ترويجي"} className="aspect-[16/7] w-full object-cover" />
    </div>
  );
  return (
    <div className="mb-5 rounded-3xl bg-[#EBCFC3] p-6">
      {sub && <p className="text-xs font-bold text-[#744838]">{sub}</p>}
      <h2 className="mt-1 max-w-xs text-xl font-extrabold leading-relaxed text-stone-800">{title}</h2>
    </div>
  );
}

export const ChatI = <Svg d={<path d="M4 5h16a1 1 0 011 1v10a1 1 0 01-1 1H9l-5 4V6a1 1 0 011-1z" />} />;
export const HomeI = <Svg d={<path d="M4 11l8-7 8 7v9a1 1 0 01-1 1h-4v-6H9v6H5a1 1 0 01-1-1z" />} />;
export const SearchI = <Svg d={<><circle cx="11" cy="11" r="7" /><path d="M20 20l-4-4" /></>} />;
export const UserI = <Svg d={<><circle cx="12" cy="8" r="4" /><path d="M4 21c0-4 3.6-7 8-7s8 3 8 7" /></>} />;
export const Heart = ({ on, c = "h-5 w-5" }) => (
  <svg viewBox="0 0 24 24" fill={on ? "currentColor" : "none"} stroke="currentColor" strokeWidth="1.8" strokeLinejoin="round" className={c} aria-hidden="true"><path d="M12 21s-8-5.2-8-11a4.5 4.5 0 018-2.8A4.5 4.5 0 0120 10c0 5.8-8 11-8 11z" /></svg>
);


/* ثيم النظام الأساسي (بيج / كريمي / وردي مغبر) لاستخدام لوحة المالك */
export const CORE = { card: cardC, btn: btnP, ghost: btnG, badge: "bg-[#EBCFC3] text-[#744838]", muted: "text-stone-600", title: "text-stone-800", row: "rounded-2xl bg-[#FDFBF7]" };
