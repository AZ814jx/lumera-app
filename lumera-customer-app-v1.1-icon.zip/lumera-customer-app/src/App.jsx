import React, { useEffect, useState } from "react";
import { useBackend, configured } from "./lib/backend";
import { Store } from "./screens/Store";
import { Auth } from "./screens/Auth";
import { Splash } from "./components/Splash";
import { Brand, btnP } from "./components/ui";

const Notice = ({ title, text, action }) => (
  <div className="flex min-h-screen items-center justify-center p-6"><div className="w-full max-w-md space-y-3 rounded-3xl bg-[#F4EFE6] p-6 text-center shadow-xl shadow-[#D9C9B8]">
    <div className="flex justify-center"><Brand /></div><h1 className="text-xl font-extrabold text-stone-800">{title}</h1><p className="text-sm leading-relaxed text-stone-600">{text}</p>
    {action && <button onClick={action.onClick} className={btnP}>{action.label}</button>}
  </div></div>
);

/* تطبيق العميل فقط (متجر + مقدمة + ودجت الدعم). لوحة الإدارة تطبيق ويب مستقل يتصل بنفس Firebase. */
export default function App() {
  const { ready, uid, profile, db, update, api, error, clearError } = useBackend("customer");
  const [screen, setScreen] = useState("store"); const [authMode, setAuthMode] = useState("login"); const [splash, setSplash] = useState(true);
  const user = profile && profile.role === "customer" ? profile : null;
  useEffect(() => { if (user) setScreen("store"); }, [user && user.id]);
  useEffect(() => { if (!error) return; const t = setTimeout(clearError, 3500); return () => clearTimeout(t); }, [error]);
  const logout = () => api.signOutUser();
  let view;
  if (!configured) view = <Notice title="الإعداد غير مكتمل" text="لم تُضبط مفاتيح Firebase. عدّل الملف public/config.js بقيم مشروعك ثم أعد بناء التطبيق (انظر README)." />;
  else if (!ready) view = <Notice title="Luméra Care" text="جارٍ التحميل..." />;
  else if (profile && profile.role !== "customer") view = <Notice title="حساب إدارة" text="هذا الحساب مخصص للمالك أو فريق الدعم. استخدم لوحة الإدارة على الويب." action={{ label: "تسجيل الخروج", onClick: logout }} />;
  else if (screen === "login" && !user) view = <Auth api={api} initial={authMode} back={() => setScreen("store")} />;
  else view = <Store db={db} update={update} user={user} uid={uid} ensureAuth={api.ensureAuth} api={api} logout={logout} goLogin={(m) => { setAuthMode(m === "signup" ? "signup" : "login"); setScreen("login"); }} />;
  return (
    <div dir="rtl" lang="ar" style={{ fontFamily: "'Cairo', sans-serif" }} className="min-h-screen bg-[#FDFBF7] text-stone-800">
      {view}
      {error && <div role="alert" className="fixed start-1/2 top-4 z-[90] -translate-x-1/2 rounded-full bg-[#4A3B34] px-5 py-2 text-sm font-semibold text-[#FDFBF7] shadow-lg">{error}</div>}
      {splash && <Splash onDone={() => setSplash(false)} />}
    </div>
  );
}
