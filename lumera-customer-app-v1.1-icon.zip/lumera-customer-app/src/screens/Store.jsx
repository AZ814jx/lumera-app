import React, { useState, useEffect, useRef } from "react";
import { SupportWidget } from "../components/SupportWidget";
import { Badge, Bottle, Brand, CartI, Field, Heart, HomeI, Modal, PromoBanner, SearchI, UserI, btnG, btnP, cardC, inC, stTone } from "../components/ui";
import { DEFAULT_BANNER } from "../lib/db";
import { CATS, ST, dt, iqd, phoneFmt } from "../lib/format";

export function Store({ db, update, user, uid, ensureAuth, api, logout, goLogin }) {
  const [tab, setTab] = useState("home"); const [q, setQ] = useState(""); const [cat, setCat] = useState("");
  const [fav, setFav] = useState([]); const [cart, setCart] = useState([]); const [open, setOpen] = useState(false); const [step, setStep] = useState("cart"); const [ro, setRo] = useState(false); const [busy, setBusy] = useState(false); const [promo, setPromo] = useState(""); const [applied, setApplied] = useState(""); const [pmsg, setPmsg] = useState(""); const [nSeen, setNSeen] = useState(null);
  const [gate, setGate] = useState(false); // نافذة "أنشئ حساباً أولاً" للزائر
  const [f, setF] = useState({ addr: "", lm: "" }); const [er, setEr] = useState({}); const [toast, setToast] = useState(""); const tRef = useRef(0);
  const set = (k) => (v) => setF((s) => ({ ...s, [k]: v && v.target ? v.target.value : v }));
  const flash = (t, ms = 1800) => { clearTimeout(tRef.current); setToast(t); tRef.current = setTimeout(() => setToast(""), ms); }; // مؤقت واحد: الإشعار الجديد لا يُقطع بمؤقت قديم
  useEffect(() => () => clearTimeout(tRef.current), []);
  useEffect(() => { if (!user) { setCart([]); setApplied(""); setPromo(""); setOpen(false); } }, [!!user]); // بعد تسجيل الخروج تُفرَّغ السلة
  const needAccount = () => { setOpen(false); setGate(true); };
  const items = cart.map((c) => ({ ...c, ...db.products.find((p) => p.id === c.id) })).filter((c) => c.name);
  const sub$ = items.reduce((a, c) => a + c.price * c.q, 0), fee = items.length ? 5000 : 0;
  const coupon = applied || null, disc = coupon ? Math.round((sub$ * coupon.pct) / 100) : 0, total = sub$ - disc + fee;
  const applyPromo = async (e) => {
    e.preventDefault(); const c = promo.trim().toUpperCase();
    if (!c) return setPmsg("أدخل كود الخصم");
    const hit = await api.getCoupon(c); // البحث بالمعرّف المشفر (SHA-256) فلا يمكن سرد الأكواد
    if (!hit) { setApplied(""); return setPmsg("كود الخصم غير صحيح"); }
    setApplied(hit); setPmsg("");
  };
  const count = cart.reduce((a, c) => a + c.q, 0);
  const add = (p) => { if (!user) return needAccount(); /* الإضافة للسلة تتطلب حساباً مسجلاً */ if (p.stock <= cart.reduce((a, c) => a + (c.id === p.id ? c.q : 0), 0)) return; setCart((c) => c.find((x) => x.id === p.id) ? c.map((x) => x.id === p.id ? { ...x, q: x.q + 1 } : x) : [...c, { id: p.id, q: 1 }]); flash("تمت الإضافة إلى السلة"); };
  const qty = (id, d) => setCart((c) => c.map((x) => x.id === id ? { ...x, q: x.q + d } : x).filter((x) => x.q > 0));
  const tgl = (id) => setFav((x) => x.includes(id) ? x.filter((i) => i !== id) : [...x, id]);
  const place = async (e) => {
    e.preventDefault(); if (busy) return;
    if (!user) return needAccount();
    const er2 = {};
    if (f.addr.trim().length < 8) er2.addr = "اكتب عنوانك بالتفصيل";
    setEr(er2); if (Object.keys(er2).length) return;
    setBusy(true);
    try {
      const nm = user.name, ph = user.phone, id = user.id;
      const oid = "GC-" + Date.now().toString(36).toUpperCase() + Math.random().toString(36).slice(2, 4).toUpperCase();
      await update((d) => {
        d.orders.unshift({ id: oid, uid: id, name: nm, phone: ph, addr: f.addr.trim(), lm: f.lm.trim(), items: items.map((i) => ({ id: i.id, n: i.name, q: i.q, p: i.price })), total, disc, coupon: coupon ? coupon.code : "", status: ST[0], at: Date.now() });
        items.forEach((i) => { const p = d.products.find((x) => x.id === i.id); if (p) p.stock = Math.max(0, p.stock - i.q); });
        return d;
      });
      setCart([]); setApplied(""); setPromo(""); setOpen(false); setStep("cart"); setTab("me"); flash("تم استلام طلبك بنجاح", 2200);
    } catch (x) {
      flash(x.message || "تعذر إتمام الطلب، حاول مجدداً", 2600);
    }
    setBusy(false);
  };
  const mine = db.orders.filter((o) => user && o.uid === user.id);
  /* إعادة شراء من الطلبات السابقة: تُضاف عناصر الطلب المسلَّم إلى السلة الحالية (تُدمج مع ما فيها) */
  const done = mine.filter((o) => o.status === ST[2]);
  /* تنبيه التوفر: تخزين (معرّف المستخدم، معرّف المنتج) ويُشعَر المشترك تلقائياً عند تحديث المخزون من لوحة المالك */
  const subbed = (id) => !!user && (db.subs || []).some((x) => x.uid === user.id && x.pid === id);
  const notifyMe = (p) => {
    if (!user) { flash("سجّل الدخول لتفعيل تنبيه التوفر"); goLogin("login"); return; }
    const was = subbed(p.id);
    update((d) => { d.subs = d.subs || []; const i = d.subs.findIndex((x) => x.uid === user.id && x.pid === p.id); if (i >= 0) d.subs.splice(i, 1); else d.subs.push({ uid: user.id, pid: p.id, at: Date.now(), name: user.name }); return d; });
    flash(was ? "تم إلغاء التنبيه" : "سنبلغك فور توفر المنتج");
  };
  const myN = (db.notifs || []).filter((n) => user && n.uid === user.id).sort((a, b) => b.at - a.at), unreadN = myN.filter((n) => !n.read).length;
  const markRead = () => update((d) => { (d.notifs || []).forEach((n) => { if (user && n.uid === user.id) n.read = true; }); return d; });
  const openNotif = (n) => { update((d) => { const t = (d.notifs || []).find((x) => x.id === n.id); if (t) t.read = true; return d; }); const pr = db.products.find((x) => x.id === n.pid); setQ(pr ? pr.name : ""); setTab("search"); };
  useEffect(() => { if (nSeen === null) { setNSeen(unreadN); return; } if (unreadN > nSeen) flash("وصلك إشعار جديد: منتج أصبح متوفراً", 2600); setNSeen(unreadN); }, [unreadN]);
  const reorder = (o) => {
    if (!user) return needAccount();
    const next = cart.map((x) => ({ ...x })); let added = 0, short = 0;
    o.items.forEach((it) => {
      const p = db.products.find((x) => x.id === it.id), cur = next.find((x) => x.id === it.id);
      const n = p ? Math.min(it.q, p.stock - (cur ? cur.q : 0)) : 0;
      if (n < it.q) short++;
      if (n <= 0) return;
      if (cur) cur.q += n; else next.push({ id: it.id, q: n });
      added++;
    });
    setCart(next); setRo(false);
    flash(added ? `تمت إضافة ${added === 1 ? "منتج واحد" : added + " منتجات"} إلى السلة${short ? " - بعض المنتجات غير متوفرة بالكمية كاملة" : ""}` : "المنتجات غير متوفرة حالياً", 2400);
  };
  const reorderUI = (
    <div className="mb-3">
      <button type="button" aria-expanded={ro} onClick={() => setRo(!ro)} className="flex w-full items-center justify-between rounded-2xl bg-[#EEDFD2] px-4 py-3 text-start text-sm font-bold text-[#744838] transition hover:bg-[#EBCFC3]">
        <span>إعادة شراء من الطلبات السابقة</span>
        <span className="flex items-center gap-2">{user && done.length > 0 && <Badge tone="rose">{done.length}</Badge>}<span aria-hidden="true" className="text-xs font-semibold">{ro ? "إخفاء" : "عرض"}</span></span>
      </button>
      {ro && <div className="mt-2 max-h-60 space-y-2 overflow-y-auto rounded-2xl bg-[#FDFBF7] p-2">
        {!user ? <p className="p-3 text-sm text-stone-600">سجّل الدخول لعرض طلباتك السابقة. <button type="button" onClick={() => { setOpen(false); goLogin("login"); }} className="font-bold text-[#8A5A47] hover:underline">تسجيل الدخول</button> أو <button type="button" onClick={() => { setOpen(false); goLogin("signup"); }} className="font-bold text-[#8A5A47] hover:underline">إنشاء حساب جديد</button></p>
          : done.length ? done.map((o) => (
            <div key={o.id} className="rounded-2xl bg-[#F4EFE6] p-3">
              <div className="flex items-center justify-between text-sm"><b className="text-stone-800">#{o.id}</b><span className="text-xs text-stone-600">{dt(o.at)}</span></div>
              <p className="mt-1 text-sm text-stone-600">{o.items.map((i) => `${i.n} (${i.q})`).join("، ")}</p>
              <button type="button" onClick={() => reorder(o)} className={btnP + " mt-2 !h-9 w-full !text-xs"}>إعادة شراء الكل</button>
            </div>))
            : <p className="p-3 text-sm text-stone-600">لا توجد طلبات مكتملة بعد. ستظهر هنا الطلبات بعد تسليمها.</p>}
      </div>}
    </div>
  );
  const shop = (arr) => (
    <div className="grid grid-cols-2 gap-4 md:grid-cols-3">{arr.map((p) => (
      <div key={p.id} className={cardC + " relative p-3 transition hover:-translate-y-0.5 hover:shadow-lg hover:shadow-[#D9C9B8]"}>
        <button onClick={() => tgl(p.id)} aria-pressed={fav.includes(p.id)} aria-label="المفضلة" className="absolute end-5 top-5 z-10 flex h-9 w-9 items-center justify-center rounded-full bg-[#FDFBF7]/90 text-[#744838] shadow-sm"><Heart on={fav.includes(p.id)} /></button>
        <Bottle img={p.img} name={p.name} />
        <p className="mt-3 text-xs text-stone-600">{p.cat}</p><h3 className="font-bold text-stone-800">{p.name}</h3>
        <div className="mt-1 flex items-center justify-between"><b className="text-[#8A5A47]">{iqd(p.price)}</b>{p.stock <= 5 && <Badge tone="amber">{p.stock ? "كمية محدودة" : "نفدت"}</Badge>}</div>
        {p.stock > 0
          ? <button onClick={() => add(p)} className={btnP + " mt-3 w-full"}>إضافة للسلة</button>
          : <button onClick={() => notifyMe(p)} aria-pressed={subbed(p.id)} className={`mt-3 h-11 w-full rounded-xl border-2 border-[#C89F8B] px-3 text-sm font-bold text-[#744838] transition active:scale-95 ${subbed(p.id) ? "bg-[#EBCFC3]" : "bg-[#FDFBF7] hover:bg-[#F4E6DE]"}`}>{subbed(p.id) ? "سنبلغك عند التوفر (إلغاء)" : "أبلغني عند التوفر"}</button>}
      </div>))}{!arr.length && <p className="col-span-full text-stone-600">لا توجد منتجات هنا</p>}</div>
  );
  const navs = [["home", "الرئيسية", HomeI], ["search", "البحث", SearchI], ["cart", "السلة", CartI], ["wish", "المفضلة", <Heart />], ["me", "حسابي", UserI]];
  return (
    <div className="mx-auto min-h-screen max-w-5xl px-4 pb-28">
      <header className="flex items-center justify-between py-5"><Brand />
        {user && <span className="text-sm font-semibold text-stone-600">{user.name}</span>}</header>
      {toast && <div role="status" aria-live="polite" style={{ bottom: "calc(5.25rem + env(safe-area-inset-bottom, 0px))" }} className="pointer-events-none fixed inset-x-0 z-[60] flex justify-center px-4"><div className="animate-toast max-w-[calc(100vw-10rem)] rounded-2xl bg-[#4A3B34] px-5 py-2.5 text-center text-sm font-semibold leading-snug text-[#FDFBF7] shadow-lg">{toast}</div></div>}
      {tab === "home" && <>
        <PromoBanner {...(db.banner || DEFAULT_BANNER)} />
        <div className="mb-4 flex flex-wrap gap-2">{["", ...CATS].map((c) => <button key={c} onClick={() => setCat(c)} className={`h-10 rounded-full px-4 text-sm font-semibold transition ${cat === c ? "bg-[#C89F8B] text-stone-800" : "bg-[#F4EFE6] text-stone-600 hover:bg-[#EEDFD2]"}`}>{c || "الكل"}</button>)}</div>
        {shop(db.products.filter((p) => !cat || p.cat === cat))}</>}
      {tab === "search" && <><input autoFocus value={q} onChange={(e) => setQ(e.target.value)} placeholder="ابحث عن منتج، ماركة..." className={inC + " mb-4"} />{shop(db.products.filter((p) => !q || p.name.includes(q) || p.cat.includes(q)))}</>}
      {tab === "wish" && <><h2 className="mb-3 font-extrabold text-stone-800">المفضلة</h2>{shop(db.products.filter((p) => fav.includes(p.id)))}</>}
      {tab === "me" && (!user ? <div className={cardC + " p-6 text-center"}><h2 className="mb-1 text-lg font-extrabold text-stone-800">مرحباً بك في Luméra Care</h2><p className="mb-5 text-sm text-stone-600">سجّل الدخول لمتابعة طلباتك، أو أنشئ حساباً جديداً باسمك ورقم هاتفك العراقي.</p><div className="flex flex-col gap-3 sm:flex-row"><button onClick={() => goLogin("login")} className={btnP + " flex-1 !h-12"}>تسجيل الدخول</button><button onClick={() => goLogin("signup")} className="h-12 flex-1 rounded-xl border-2 border-[#C89F8B] bg-[#FDFBF7] px-5 text-sm font-bold text-[#744838] transition hover:bg-[#F4E6DE] active:scale-95">إنشاء حساب جديد</button></div></div> : <>
        <div className={cardC + " mb-4 flex items-center justify-between p-4"}><div><b className="text-stone-800">{user.name}</b><p dir="ltr" className="text-start text-sm text-stone-600">{phoneFmt(user.phone)}</p></div><button onClick={logout} className={btnG}>خروج</button></div>
        <div className="mb-5">
          <div className="mb-2 flex items-center justify-between"><h2 className="font-extrabold text-stone-800">الإشعارات{unreadN > 0 && <span className="ms-2"><Badge tone="rose">{unreadN} جديد</Badge></span>}</h2>{unreadN > 0 && <button onClick={markRead} className="text-xs font-bold text-[#8A5A47] hover:underline">تحديد الكل كمقروء</button>}</div>
          {myN.length ? <div className="space-y-2">{myN.slice(0, 5).map((n) => (
            <div key={n.id} className={`rounded-2xl p-3 text-sm ${n.read ? "bg-[#F4EFE6] text-stone-600" : "bg-[#EBCFC3] text-stone-800"}`}><p>{n.text}</p>
              <div className="mt-1 flex items-center justify-between text-xs"><span className="text-stone-600">{dt(n.at)}</span><button onClick={() => openNotif(n)} className="font-bold text-[#744838] hover:underline">عرض المنتج</button></div></div>))}</div> : <p className="text-sm text-stone-600">لا توجد إشعارات بعد</p>}
        </div>
        <h2 className="mb-3 font-extrabold text-stone-800">طلباتي</h2>
        <div className="space-y-3">{mine.map((o) => (
          <div key={o.id} className={cardC + " p-4"}><div className="flex items-center justify-between"><b className="text-stone-800">#{o.id}</b><Badge tone={stTone(o.status)}>{o.status}</Badge></div>
            <p className="mt-1 text-sm text-stone-600">{o.items.map((i) => `${i.n} (${i.q})`).join("، ")}</p><p className="mt-1 text-sm text-stone-600">{o.addr}{o.lm ? " - " + o.lm : ""}</p>{o.coupon && <p className="mt-1 text-sm text-[#4A6340]">خصم {o.coupon}: -{iqd(o.disc)}</p>}<b className="mt-2 block text-[#8A5A47]">{iqd(o.total)}</b></div>))}{!mine.length && <p className="text-stone-600">لا توجد طلبات بعد</p>}</div></>)}
      <SupportWidget db={db} update={update} user={user} uid={uid} ensureAuth={ensureAuth} />
      <nav aria-label="التنقل الرئيسي" className="fixed inset-x-0 bottom-0 z-40 mx-auto flex max-w-lg items-center justify-around rounded-t-3xl bg-[#F4EFE6] px-2 pt-2 shadow-[0_-6px_24px_rgba(120,90,70,0.12)]" style={{ paddingBottom: "max(0.5rem, env(safe-area-inset-bottom))" }}>
        {navs.map(([k, t, ic]) => { const on = k !== "cart" && tab === k; return (
          <button key={k} aria-current={on ? "page" : undefined} onClick={() => (k === "cart" ? (setOpen(true), setStep("cart")) : setTab(k))} className={`relative flex min-h-[3.25rem] flex-1 flex-col items-center justify-center gap-0.5 rounded-2xl text-[11px] font-bold transition ${on ? "bg-[#EBCFC3] text-[#744838]" : "text-stone-600 hover:text-[#744838]"}`}>
            <span className="relative">{ic}{k === "cart" && count > 0 && <span className="absolute -end-2 -top-2 flex h-4 min-w-4 items-center justify-center rounded-full bg-[#C89F8B] px-1 text-[10px] text-stone-800">{count}</span>}{k === "wish" && fav.length > 0 && <span className="absolute -end-1.5 -top-1 h-2 w-2 rounded-full bg-[#C89F8B]" />}{k === "me" && unreadN > 0 && <span className="absolute -end-1.5 -top-1 h-2.5 w-2.5 rounded-full bg-[#744838]" />}</span>{t}</button>); })}
      </nav>
      {open && <Modal title={step === "cart" ? "سلة التسوق" : "إتمام الطلب"} onClose={() => setOpen(false)}>
        {step === "cart" ? (<>{reorderUI}{items.length ? <div className="space-y-3">{items.map((i) => (
          <div key={i.id} className="flex items-center gap-3 rounded-2xl bg-[#EEDFD2] p-3"><div className="flex-1"><p className="font-bold text-stone-800">{i.name}</p><p className="text-sm text-[#8A5A47]">{iqd(i.price * i.q)}</p></div>
            <div className="flex items-center gap-2"><button aria-label="إنقاص" onClick={() => qty(i.id, -1)} className={btnG + " !h-9 !px-3"}>-</button><b>{i.q}</b><button aria-label="زيادة" onClick={() => i.q < i.stock && qty(i.id, 1)} className={btnG + " !h-9 !px-3"}>+</button></div></div>))}
          <form onSubmit={applyPromo} className="flex gap-2 pt-1"><input value={promo} onChange={(e) => { setPromo(e.target.value); setPmsg(""); }} placeholder="كود الخصم" aria-label="كود الخصم" dir="ltr" className={inC + " text-start uppercase"} /><button className={btnG + " shrink-0"}>تطبيق</button></form>
          {pmsg && <p role="alert" className="text-xs font-semibold text-[#8A5A47]">{pmsg}</p>}
          {coupon && <p role="status" className="flex items-center justify-between rounded-2xl bg-[#DDE8D5] px-3 py-2 text-sm font-semibold text-[#4A6340]"><span>تم تطبيق الكود {coupon.code} (خصم {coupon.pct}%)</span><button type="button" onClick={() => { setApplied(""); setPromo(""); }} className="text-xs underline">إزالة</button></p>}
          <div className="space-y-1 border-t border-[#E3D5C6] pt-3 text-sm text-stone-700"><p className="flex justify-between"><span>المجموع</span><b>{iqd(sub$)}</b></p>{coupon && <p className="flex justify-between text-[#4A6340]"><span>الخصم ({coupon.pct}%)</span><b>-{iqd(disc)}</b></p>}<p className="flex justify-between"><span>التوصيل</span><b>{iqd(fee)}</b></p><p className="flex justify-between text-base"><b>الإجمالي</b><b className="text-[#8A5A47]">{iqd(total)}</b></p></div>
          <button onClick={() => (user ? setStep("form") : needAccount())} className={btnP + " w-full"}>إتمام الطلب</button></div> : <p className="text-stone-600">السلة فارغة</p>}</>) : (
          <form onSubmit={place} className="space-y-3">
            {user && <p className="rounded-2xl bg-[#EEDFD2] p-3 text-sm text-stone-600">الطلب باسم <b>{user.name}</b> - <span dir="ltr">{phoneFmt(user.phone)}</span></p>}
            <Field label="عنوان التوصيل" error={er.addr}><textarea rows={2} value={f.addr} onChange={set("addr")} placeholder="المحافظة، المنطقة، الشارع، رقم الدار" className={inC + " h-auto py-2"} /></Field>
            <Field label="أقرب نقطة دالة"><input value={f.lm} onChange={set("lm")} className={inC} /></Field>
            <p className="flex justify-between text-sm text-stone-700"><span>الإجمالي شامل التوصيل (الدفع عند الاستلام)</span><b className="text-[#8A5A47]">{iqd(total)}</b></p>
            <div className="flex gap-2"><button type="button" onClick={() => setStep("cart")} className={btnG}>رجوع</button><button className={btnP + " flex-1"}>تأكيد الطلب</button></div></form>)}
      </Modal>}
      {gate && <Modal title="أنشئ حسابك أولاً" onClose={() => setGate(false)}>
        <p className="mb-4 text-sm leading-relaxed text-stone-600">لإضافة المنتجات إلى السلة وإتمام الطلب، يرجى إنشاء حساب جديد برقم هاتفك العراقي. يستغرق ذلك أقل من دقيقة.</p>
        <div className="flex flex-col gap-2">
          <button onClick={() => { setGate(false); goLogin("signup"); }} className={btnP + " !h-12 w-full"}>إنشاء حساب جديد</button>
          <button onClick={() => { setGate(false); goLogin("login"); }} className={btnG + " !h-11 w-full"}>لدي حساب بالفعل - تسجيل الدخول</button>
        </div>
      </Modal>}
    </div>
  );
}
