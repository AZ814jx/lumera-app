import React, { useState } from "react";
import { Brand, Collapse, Field, PasswordField, PhoneField, btnG, btnP, inC } from "../components/ui";
import { okPhone } from "../lib/format";

/* تسجيل الدخول وإنشاء الحساب (رقم الهاتف +964 وكلمة المرور) عبر Firebase Auth.
   حسابات الإدارة (المالك/الدعم) لا تُستخدم هنا بل في لوحة الويب المستقلة. */
export function Auth({ api, back, initial = "login" }) {
  const [mode, setMode] = useState(initial);
  const [f, setF] = useState({ name: "", phone: "", pw: "", pw2: "" });
  const [er, setEr] = useState({}); const [busy, setBusy] = useState(false); const [done, setDone] = useState(false);
  const signup = mode === "signup";
  const set = (k) => (e) => { const v = e && e.target ? e.target.value : e; setF((s) => ({ ...s, [k]: v })); setEr({}); };
  const switchMode = (m) => { setMode(m); setEr({}); };
  const submit = async (e) => {
    e.preventDefault(); if (busy || done) return;
    const err = {};
    if (!okPhone(f.phone)) err.phone = "أدخل رقم هاتف عراقي صحيح، مثال: 770 123 4567";
    if (signup) {
      if (f.name.trim().length < 3) err.name = "يرجى إدخال الاسم الكامل";
      if (f.pw.length < 6) err.pw = "كلمة المرور يجب ألا تقل عن 6 أحرف";
      else if (f.pw2 !== f.pw) err.pw2 = "كلمتا المرور غير متطابقتين";
    } else if (!f.pw) err.pw = "أدخل كلمة المرور";
    if (Object.keys(err).length) return setEr(err);
    setBusy(true);
    try { if (signup) await api.signUp({ name: f.name.trim(), phone: f.phone, pw: f.pw }); else await api.signIn(f.phone, f.pw); setDone(true); }
    catch (x) { setBusy(false); if (x.code === "phone-taken") setEr({ phone: "هذا الرقم مسجل مسبقاً." }); else setEr({ form: x.message }); }
  };
  return (
    <div className="flex min-h-screen flex-col">
      <header className="mx-auto flex w-full max-w-md items-center justify-between px-5 pt-6"><Brand /><button onClick={back} className={btnG}>المتابعة كـ ضيف</button></header>
      <main className="flex flex-1 items-center justify-center px-4 py-8">
        <form onSubmit={submit} noValidate className="w-full max-w-md space-y-4 rounded-3xl bg-[#F4EFE6] p-6 shadow-xl shadow-[#D9C9B8] sm:p-8">
          <div role="tablist" aria-label="نوع النموذج" className="relative grid grid-cols-2 rounded-2xl bg-[#EEDFD2] p-1">
            <span aria-hidden="true" className={`absolute inset-y-1 right-1 w-[calc(50%-4px)] rounded-xl bg-[#FDFBF7] shadow-sm transition-transform duration-300 ease-out motion-reduce:transition-none ${signup ? "-translate-x-full" : "translate-x-0"}`} />
            {[["login", "تسجيل الدخول"], ["signup", "إنشاء حساب"]].map(([k, t]) => (
              <button key={k} type="button" role="tab" aria-selected={mode === k} onClick={() => switchMode(k)} className={`relative z-10 h-11 rounded-xl text-sm font-bold transition-colors ${mode === k ? "text-[#744838]" : "text-stone-600 hover:text-stone-800"}`}>{t}</button>
            ))}
          </div>
          <div>
            <h1 className="text-2xl font-extrabold text-stone-800">{signup ? "أنشئي حسابك الجديد" : "أهلاً بعودتك"}</h1>
            <p className="mt-1 text-sm text-stone-600">{signup ? "برقم هاتفك العراقي فقط، وتتابعين طلباتك بسهولة" : "سجّلي الدخول لمتابعة طلباتك وقوائمك"}</p>
          </div>
          <Collapse open={signup}>
            <Field label="الاسم الكامل" error={signup ? er.name : null}>
              <input value={f.name} onChange={set("name")} autoComplete="name" disabled={!signup} placeholder="مثال: سارة أحمد" className={inC} />
            </Field>
          </Collapse>
          <PhoneField value={f.phone} onChange={set("phone")} error={er.phone} />
          {signup && er.phone && er.phone.startsWith("هذا الرقم") && (
            <button type="button" onClick={() => switchMode("login")} className="-mt-2 text-sm font-bold text-[#8A5A47] hover:underline">لديك حساب بهذا الرقم؟ سجّل الدخول</button>
          )}
          <PasswordField id="pw" label="كلمة المرور" value={f.pw} onChange={set("pw")} error={er.pw} auto={signup ? "new-password" : "current-password"} />
          <Collapse open={signup}>
            <PasswordField id="pw2" label="تأكيد كلمة المرور" value={f.pw2} onChange={set("pw2")} error={signup ? er.pw2 : null} auto="new-password" />
          </Collapse>
          {er.form && <p role="alert" className="rounded-2xl bg-[#F4E6DE] px-3 py-2 text-sm font-semibold text-[#744838]">{er.form}</p>}
          {done && <p role="status" className="rounded-2xl bg-[#DDE8D5] px-3 py-2 text-sm font-semibold text-[#4A6340]">{signup ? "تم إنشاء حسابك بنجاح" : "تم تسجيل الدخول"} - جارٍ التحويل...</p>}
          <button disabled={busy || done} className={btnP + " w-full"}>{busy ? "جارٍ المعالجة..." : signup ? "إنشاء حساب" : "تسجيل الدخول"}</button>
          <p className="text-center text-sm text-stone-600">
            {signup ? "لديك حساب بالفعل؟" : "ليس لديك حساب؟"}{" "}
            <button type="button" onClick={() => switchMode(signup ? "login" : "signup")} className="font-bold text-[#8A5A47] hover:underline">{signup ? "تسجيل الدخول" : "إنشاء حساب"}</button>
          </p>
        </form>
      </main>
    </div>
  );
}
