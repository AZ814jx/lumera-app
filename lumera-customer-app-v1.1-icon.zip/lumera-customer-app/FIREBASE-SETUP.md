# إعداد Firebase (مرة واحدة)

التطبيقان (لوحة الإدارة وتطبيق العميل) يتصلان بنفس مشروع Firebase، لذلك أي تعديل من المالك يظهر فوراً داخل تطبيق العميل. الخطة المجانية Spark تكفي.

1. أنشئ مشروعاً في https://console.firebase.google.com ثم أضف تطبيق ويب (Web app) وانسخ الإعدادات (apiKey وغيرها).
2. Authentication > Sign-in method: فعّل **Email/Password** و **Anonymous**.
3. Firestore Database: أنشئ قاعدة بيانات (Production mode).
4. Firestore > Rules: الصق محتوى الملف `firestore.rules` المرفق (أو `firebase/firestore.rules`) ثم Publish.
5. **حساب المالك الأول (يدوياً مرة واحدة):**
   - Authentication > Users > Add user: بريدك الإلكتروني الحقيقي وكلمة مرور قوية (هذا ما تدخل به إلى لوحة الإدارة).
   - انسخ الـ User UID ثم Firestore > Start collection باسم `users` > Document ID = ذلك الـ UID، الحقول: `name` (string) = المالك، `email` (string) = بريدك، `role` (string) = owner، `at` (number) = 0.
6. بعد نشر لوحة الإدارة أضف نطاقها إلى Authentication > Settings > Authorized domains.
7. من لوحة الإدارة (تبويب نظرة عامة) اضغط "استيراد البيانات التجريبية" لإضافة المنتجات وأكواد الخصم والبانر.
8. موظفو الدعم: من لوحة الإدارة > الموظفون أضف الاسم والبريد الإلكتروني وكلمة المرور، فيدخلون بالبريد وكلمة المرور فقط.

الصلاحيات تُفرض على الخادم عبر `firestore.rules`: الأدوار customer / support / owner في `users/{uid}.role`.

ملاحظة: العملاء (تطبيق الجوال) يسجلون برقم الهاتف داخل التطبيق، أما فريق Luméra فيدخل إلى لوحة الإدارة بالبريد الإلكتروني وكلمة المرور فقط.
