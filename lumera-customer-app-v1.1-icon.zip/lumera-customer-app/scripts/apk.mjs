#!/usr/bin/env node
// One-command APK build.
//   npm run doctor        -> check prerequisites only
//   npm run apk:debug     -> installable debug APK  (lumera-care-<version>-debug.apk)
//   npm run apk:release   -> unsigned release APK   (must be signed before install/publish)
// Steps: checks -> Vite build -> create android project (first run) -> icons -> cap sync -> Gradle -> copy APK
import { spawnSync } from "node:child_process";
import fs from "node:fs";
import path from "node:path";
import os from "node:os";

const arg = process.argv[2];
const doctorOnly = arg === "doctor";
const mode = arg === "release" ? "release" : "debug";
const win = process.platform === "win32";
const say = (m) => console.log("\n==> " + m);
const warn = (m) => console.warn("WARNING: " + m);
const fail = (m) => { console.error("\nERROR: " + m); process.exit(1); };
const run = (cmd, args, opts = {}) => {
  const r = spawnSync(cmd, args, { stdio: "inherit", shell: win, ...opts });
  if (r.status !== 0) fail("Command failed: " + cmd + " " + args.join(" "));
};

// 0) Node
const nodeMajor = Number(process.versions.node.split(".")[0]);
if (nodeMajor < 18) fail("Node 18 or newer is required (you have " + process.versions.node + ").");
if (!fs.existsSync("node_modules")) fail("Dependencies are not installed. Run: npm install");

// 1) Firebase config
const cfg = fs.existsSync("public/config.js") ? fs.readFileSync("public/config.js", "utf8") : "";
const env = fs.existsSync(".env") ? fs.readFileSync(".env", "utf8") : "";
const hasKeys = /apiKey:\s*"(?!YOUR)[^"]+"/.test(cfg) || /VITE_FIREBASE_API_KEY=(?!YOUR)\S+/.test(env);
if (!hasKeys && !process.argv.includes("--force")) fail("Firebase keys are not set. Edit public/config.js (see FIREBASE-SETUP.md) and re-run.");
const pid = (/projectId:\s*"([^"]+)"/.exec(cfg) || [])[1];
if (pid) console.log("Firebase project baked into the app: " + pid);

// 2) JDK (Capacitor 6 / Gradle needs 17; 21 works after the wrapper upgrade below)
const javaBin = process.env.JAVA_HOME && fs.existsSync(path.join(process.env.JAVA_HOME, "bin", win ? "java.exe" : "java"))
  ? path.join(process.env.JAVA_HOME, "bin", "java") : "java";
const jv = spawnSync(javaBin, ["-version"], { encoding: "utf8", shell: win });
if (jv.error || jv.status !== 0) fail("JDK not found. Install JDK 17 and make sure `java -version` works (or set JAVA_HOME).");
const jm = /version "(\d+)(?:\.(\d+))?/.exec((jv.stderr || "") + (jv.stdout || ""));
const javaMajor = jm ? (jm[1] === "1" ? Number(jm[2]) : Number(jm[1])) : 0;
if (javaMajor < 17) fail("JDK 17 or newer is required (found " + (javaMajor || "unknown") + ").");
if (javaMajor > 21) fail("JDK " + javaMajor + " is too new for this Android toolchain. Install JDK 17 (recommended) or 21.");
console.log("JDK: " + javaMajor);

// 3) Android SDK
const candidates = [process.env.ANDROID_HOME, process.env.ANDROID_SDK_ROOT, path.join(os.homedir(), "Android", "Sdk"), path.join(os.homedir(), "Library", "Android", "sdk"), process.env.LOCALAPPDATA && path.join(process.env.LOCALAPPDATA, "Android", "Sdk")].filter(Boolean);
const sdk = candidates.find((p) => fs.existsSync(p));
if (!sdk) fail("Android SDK not found. Install Android Studio (it installs the SDK) or set ANDROID_HOME to the SDK folder.");
console.log("Android SDK: " + sdk);
if (!fs.existsSync(path.join(sdk, "licenses"))) warn("SDK licenses not accepted yet. If Gradle fails on a missing component, run: sdkmanager --licenses");

if (doctorOnly) { say("All prerequisite checks passed. Run: npm run apk:debug"); process.exit(0); }

// 4) Build the web app
say("Building the web app (Vite)");
run("npx", ["vite", "build"]);

// 5) Android project + icons (first run only)
if (!fs.existsSync("android")) {
  say("Creating the Android project (Capacitor)");
  run("npx", ["cap", "add", "android"]);
}
// Icons + splash are regenerated on every build from resources/ (icon-only, icon-foreground, icon-background, splash)
say("Generating app icons and splash screen");
const ra = spawnSync("npx", ["capacitor-assets", "generate", "--android", "--assetPath", "resources"], { stdio: "inherit", shell: win });
if (ra.status !== 0) warn("Could not generate icons; the previous/default icon will be used.");

// 6) Sync web build into the Android project
say("Syncing web build into the Android project");
run("npx", ["cap", "sync", "android"]);
fs.writeFileSync(path.join("android", "local.properties"), "sdk.dir=" + sdk.replace(/\\/g, "/") + "\n");

// 6b) Display name + icon wiring (name comes from "appName" in capacitor.config.json)
const appName = JSON.parse(fs.readFileSync("capacitor.config.json", "utf8")).appName;
const xmlEsc = (t) => t.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, '\\"').replace(/'/g, "\\'");
const stringsXml = path.join("android", "app", "src", "main", "res", "values", "strings.xml");
let sx = fs.readFileSync(stringsXml, "utf8");
sx = sx.replace(/(<string name="app_name">)[^<]*(<\/string>)/, (m, a, b) => a + xmlEsc(appName) + b)
       .replace(/(<string name="title_activity_main">)[^<]*(<\/string>)/, (m, a, b) => a + xmlEsc(appName) + b);
fs.writeFileSync(stringsXml, sx);
const manifestXml = path.join("android", "app", "src", "main", "AndroidManifest.xml");
let mx = fs.readFileSync(manifestXml, "utf8");
const setAttr = (tag, name, val) => new RegExp(name + '="[^"]*"').test(tag) ? tag.replace(new RegExp(name + '="[^"]*"'), name + '="' + val + '"') : tag.replace("<application", "<application " + name + '="' + val + '"');
mx = mx.replace(/<application[^>]*>/, (tag) => [["android:label", "@string/app_name"], ["android:icon", "@mipmap/ic_launcher"], ["android:roundIcon", "@mipmap/ic_launcher_round"]].reduce((t, [n, v]) => setAttr(t, n, v), tag));
fs.writeFileSync(manifestXml, mx);
if (!fs.readFileSync(stringsXml, "utf8").includes(">" + xmlEsc(appName) + "<")) fail("Could not set the app name in strings.xml");
console.log("App display name: " + appName);

// 7) JDK 21 needs a newer Gradle than the Capacitor 6 template ships with
if (javaMajor >= 21) {
  const wp = path.join("android", "gradle", "wrapper", "gradle-wrapper.properties");
  if (fs.existsSync(wp)) {
    const t = fs.readFileSync(wp, "utf8");
    const u = t.replace(/gradle-[\d.]+-(all|bin)\.zip/, "gradle-8.7-all.zip");
    if (u !== t) { fs.writeFileSync(wp, u); console.log("Upgraded Gradle wrapper to 8.7 for JDK " + javaMajor); }
  }
}

// 7b) Stamp the app version (single source of truth: "android" block in package.json)
const pkg = JSON.parse(fs.readFileSync("package.json", "utf8"));
const ver = pkg.android || {};
if (!ver.versionName || !Number.isInteger(ver.versionCode)) fail('package.json needs: "android": { "versionName": "v1.1", "versionCode": 2 }');
const gradleFile = path.join("android", "app", "build.gradle");
let gradle = fs.readFileSync(gradleFile, "utf8");
gradle = gradle.replace(/versionCode\s+\d+/, "versionCode " + ver.versionCode).replace(/versionName\s+"[^"]*"/, 'versionName "' + ver.versionName + '"');
if (!gradle.includes("versionCode " + ver.versionCode) || !gradle.includes('versionName "' + ver.versionName + '"')) fail("Could not set the version in android/app/build.gradle");
fs.writeFileSync(gradleFile, gradle);
console.log("App version: " + ver.versionName + " (versionCode " + ver.versionCode + ")");

// 8) Gradle
say("Building the APK (" + mode + ") with Gradle - the first run can take several minutes");
if (!win) fs.chmodSync(path.join("android", "gradlew"), 0o755);
run(win ? "gradlew.bat" : "./gradlew", [mode === "release" ? "assembleRelease" : "assembleDebug"], { cwd: "android" });

const apk = path.join("android", "app", "build", "outputs", "apk", mode, mode === "release" ? "app-release-unsigned.apk" : "app-debug.apk");
if (!fs.existsSync(apk)) fail("APK not found after build: " + apk);
const out = "lumera-care-" + ver.versionName + "-" + mode + ".apk";
fs.copyFileSync(apk, out);
say("Done. APK: " + path.resolve(out));
if (mode === "release") console.log("This release APK is UNSIGNED and cannot be installed until you sign it. For testing, use: npm run apk:debug");
else console.log("Install on a connected phone with: adb install -r " + out + "   (or copy the file to the phone and open it)");
