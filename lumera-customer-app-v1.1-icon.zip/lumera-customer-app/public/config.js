/* Firebase config for the customer app: same project as the admin dashboard (lumera-care),
   so everything syncs instantly. These are public identifiers, not secrets; data is protected
   by Firestore rules. After any change here, re-run: npm run apk:debug */
window.LUMERA_FIREBASE = {
  apiKey: "AIzaSyD4we8lJ0AO2VLph6zHstcq4IWSyvLN46E",
  authDomain: "lumera-care.firebaseapp.com",
  projectId: "lumera-care",
  storageBucket: "lumera-care.firebasestorage.app",
  messagingSenderId: "1073987279906",
  appId: "1:1073987279906:web:899126b294be6f097a3e7b",
  measurementId: "G-NGC7C4LF5G",
};
